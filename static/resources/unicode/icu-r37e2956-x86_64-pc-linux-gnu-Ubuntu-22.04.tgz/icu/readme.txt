ICU Version: 72.0.1
HOST: x86_64-pc-linux-gnu
CC Compiler: gcc
CXX Compiler: g++
