GreenHmong keyboard
==============

Aaron Cornelius
https://languagetools-153419.appspot.com/nyiakeng/downloads/

Version 0.1

Description
-----------

This package provides two seperate Hmong keyboards.
The first is a simple keyboard based on the template provided by a Hmong community.
The second is a proof-of-concept phonetic keyboard. This is provided as an example only, and would need to be modified for the specific language requirements.

Links
-----

Supported Platforms
-------------------
 * Windows
 * macOS
 * Linux
 * Web
 * iPhone
 * iPad
 * Android phone
 * Android tablet
 * Mobile devices
 * Desktop devices
 * Tablet devices

